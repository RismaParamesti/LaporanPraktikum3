import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // Deklarasi variabel data sebagai list
  final List<String> data = [];

  MyApp({Key? key}) : super(key: key) {
    // Mengisi data listview
    for (int i = 0; i < 20; i++) {
      data.add("Data ke $i");
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            title: const Text(''),
            bottom: TabBar(
              // Menggunakan labelColor untuk mengatur warna teks Tab
              labelColor: Colors.white,
              tabs: [
                Tab(
                  text: "For You",
                ),
                Tab(
                  text: "Following",
                ),
              ],
            ),
            backgroundColor: Colors.blue, // Warna latar belakang AppBar
          ),
          body: TabBarView(
            children: [
              // Menggunakan ListView untuk tab "For You"
              Container(
                color: Color.fromARGB(
                    255, 252, 252, 252), // Warna latar belakang tab "For You"
                child: ListView.builder(
                  itemCount: data.length,
                  itemBuilder: (context, index) {
                    return ListTile(
                      leading: FlutterLogo(), // Gambar logo Flutter
                      title: Text(data[index]),
                    );
                  },
                ),
              ),
              // Isi tab "Following"
              Container(
                color: Color.fromARGB(255, 255, 255, 255),
                child: GridView.count(
                  crossAxisCount: 2,
                  padding: const EdgeInsets.all(8),
                  children: [
                    buildMenuItem(
                        'https://flutter.github.io/assets-for-api-docs/assets/widgets/owl-2.jpg'),
                    buildMenuItem(
                        'https://flutter.github.io/assets-for-api-docs/assets/widgets/owl-2.jpg'),
                    buildMenuItem(
                        'https://flutter.github.io/assets-for-api-docs/assets/widgets/owl-2.jpg'),
                    buildMenuItem(
                        'https://flutter.github.io/assets-for-api-docs/assets/widgets/owl-2.jpg'),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildMenuItem(String imageUrl) {
    return Card(
      elevation: 0, // Menghilangkan bayangan kotak
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.network(
            imageUrl,
            width: 200, // Ukuran gambar
            height: 200, // Ukuran gambar
            fit: BoxFit.cover,
          ),
          SizedBox(height: 8),
          Text(""), // Title dapat diatur sesuai kebutuhan
        ],
      ),
    );
  }
}
