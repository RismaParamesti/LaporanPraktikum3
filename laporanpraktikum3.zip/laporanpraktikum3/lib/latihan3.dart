import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(60.0),
          child: AppBar(
            title: Text(
              'Tuiter',
              style: TextStyle(
                color: Colors.white, // Mengatur warna teks menjadi putih
              ),
            ),
            backgroundColor: Color.fromARGB(255, 55, 139, 235),
          ),
        ),
        body: SafeArea(
          child: Stack(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    constraints: BoxConstraints.expand(
                      height: 200,
                    ), // Atur tinggi kontainer sampul
                    color: Colors.grey[300],
                    child: Stack(
                      children: [
                        Positioned(
                          top: 10,
                          left: 10, // Atur posisi ikon back ke kiri
                          child: IconButton(
                            onPressed: () {
                              // Tambahkan fungsi untuk tombol back di sini
                            },
                            icon: Icon(Icons.arrow_back),
                          ),
                        ),
                        Positioned(
                          top: 10,
                          right: 10,
                          child: Row(
                            children: [
                              IconButton(
                                onPressed: () {
                                  // Tambahkan fungsi untuk tombol pencarian di sini
                                },
                                icon: Icon(Icons.search),
                              ),
                              IconButton(
                                onPressed: () {
                                  // Tambahkan fungsi untuk tombol more di sini
                                },
                                icon: Icon(Icons.more_vert),
                              ),
                            ],
                          ),
                        ),
                        Positioned.fill(
                          child: AspectRatio(
                            aspectRatio:
                                1, // Rasio aspek 1:1 untuk membuatnya menjadi kotak
                            child: Image.network(
                              'https://flutter.github.io/assets-for-api-docs/assets/widgets/owl-2.jpg',
                              fit: BoxFit.cover, // Menggunakan BoxFit.cover
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.only(top: 50, left: 16, right: 16),
                    color: Colors.white,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'UPI Official',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 20,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 8),
                        SizedBox(height: 8),
                      ],
                    ),
                  ),
                ],
              ),
              Positioned(
                top: 140,
                left: 20,
                child: ClipRRect(
                  child: Container(
                    width: 100,
                    height: 100,
                    decoration: BoxDecoration(
                      color: Colors.white,
                    ),
                    child: Image.network(
                      'https://flutter.github.io/assets-for-api-docs/assets/widgets/owl-2.jpg',
                      fit: BoxFit.cover, // Ubah menjadi BoxFit.cover
                    ),
                  ),
                ),
              ),
              Positioned(
                top: 199.9, // Atur posisi tombol ke pojok kanan atas
                right: 16,
                child: ElevatedButton(
                  onPressed: () {
                    // Tambahkan fungsi untuk tombol follow di sini
                  },
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      // Membuat tombol menjadi berbentuk kotak
                      borderRadius:
                          BorderRadius.circular(15), // Mengatur border radius
                    ),
                    padding: EdgeInsets.symmetric(
                        vertical: 10,
                        horizontal: 20), // Atur padding vertikal dan horizontal
                    backgroundColor: const Color.fromARGB(
                        255, 55, 139, 235), // Warna latar belakang tombol
                    foregroundColor: Colors.white, // Warna teks tombol
                    // Atur margin atas tombol
                    elevation: 2,
                    shadowColor: Colors.grey,
                  ),
                  child: Text(
                    'Follow',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      // Membuat teks "Follow" menjadi tebal
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
