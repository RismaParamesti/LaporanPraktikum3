import 'package:flutter/material.dart';

void main() {
  runApp(MyApp()); // Hilangkan const di sini
}

class MyApp extends StatelessWidget {
  // Hapus const dari konstruktor karena ada inisialisasi data di dalamnya
  MyApp({Key? key}) : super(key: key);

  // Sample data
  final List<Map<String, dynamic>> userData = [
    {
      'name': 'Risma',
      'hobby': 'Membaca Novel',
      'profileImageAsset': 'assets/fotoRisma.jpeg' // Pastikan path benar
    },
    {
      'name': 'Hanim',
      'hobby': 'Bernyanyi',
      'profileImageAsset': 'assets/fotoHanim.jpeg' // Pastikan path benar
    },
    // Add more data as needed
  ];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Card'), // const dapat digunakan di sini
        ),
        body: ListView.builder(
          itemCount: userData.length,
          itemBuilder: (context, index) {
            return UserCard(
              name: userData[index]['name']!,
              hobby: userData[index]['hobby']!,
              profileImageAsset: userData[index]['profileImageAsset']!,
            );
          },
        ),
      ),
    );
  }
}

class UserCard extends StatelessWidget {
  final String name;
  final String hobby;
  final String profileImageAsset;

  // Tidak perlu mengubah apa pun di sini, karena konstruktor ini tidak diharapkan menjadi const
  const UserCard({
    required this.name,
    required this.hobby,
    required this.profileImageAsset,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(8.0),
      child: ListTile(
        leading: CircleAvatar(
          // Pastikan ini sesuai dengan tipe sumber gambar Anda (lokal atau jaringan)
          backgroundImage: AssetImage(profileImageAsset), // Untuk asset lokal
        ),
        title: Text(name),
        subtitle: Text(hobby),
        trailing: const Icon(Icons.more_vert), // const dapat digunakan di sini
      ),
    );
  }
}
